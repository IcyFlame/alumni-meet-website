<div class="slideshow" style="bottom: 10px; position: fixed;">

	<img src="sponsor-images/1.png" height="150" width="150"/>
	<img src="sponsor-images/2.png" height="150" width="150"/>
	<img src="sponsor-images/3.png" height="150" width="150"/>
	<img src="sponsor-images/4.png" height="150" width="150"/>
	<img src="sponsor-images/5.png" height="150" width="150"/>
	<img src="sponsor-images/6.png" height="150" width="150"/>
	<img src="sponsor-images/7.png" height="150" width="150"/>
	<img src="sponsor-images/8.png" height="150" width="150"/>
	<img src="sponsor-images/9.png" height="150" width="150"/>
	<img src="sponsor-images/10.png" height="150" width="150"/>
	<img src="sponsor-images/11.png" height="150" width="150"/>
	<img src="sponsor-images/12.png" height="150" width="150"/>
	<img src="sponsor-images/13.png" height="150" width="150"/>

</div>