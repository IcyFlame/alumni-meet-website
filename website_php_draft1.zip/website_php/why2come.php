<html>

<head>

	<title>12th Alumni Meet</title>

	<?php include("mainStyle.php");?>


</head>

<body background="bg.jpg">

	<div id="topbar" class="navbar">

		<?php include("menubar.php"); ?>

	</div>

	<br/>
	<br/>

	<div class="col-md-1"></div>

	<div class="col-md-9">
		<div id="" style="position:relative;background-image:url('why2comeimages/back.png');padding-left:65px;padding-right:35px;padding-top:30px;margin-bottom:40px;border-radius:10px; text-align: justify;">

			<?php include("points_why2come.php"); ?>

		</div>

	</div>

	<div class="col-md-2" style="text-align: center;">

			<?php include("socialIcons.php"); ?>		

	</div>


</body>

</html>
