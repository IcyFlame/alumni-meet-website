<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/menubar.css">
<link rel="stylesheet" href="css/bootstrap_customisation.css">
<link rel="stylesheet" href="css/button.css">
<link rel="stylesheet" href="css/body_customise.css">

<script src="js/jquery-2.1.0.min.js"></script>

<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>

<script type="text/javascript" src="sponsor-cycle/cycle.js"></script>
<script type="text/javascript" src="sponsor-cycle/cycle-script.js"></script>