<a href="home_page.html"><img src="logo.jpg" class="logo" style="height:170px; width:280px"></a>

<div id="cssmenu">

	<ul>
		<!-- <li class="has-image"><a href='index.html'><img src="logo.jpg" class="logo" style="height:170px;width:280px"></a></li> -->
		<li><a href='home_page.html'><span>Home</span></a></li>
		<li class='has-sub'><a href='#'><span>Meet 2015</span></a>
			<ul>
				<li><a href='why2come.php'><span>Why to Come</span></a></li>
				<li><a href='events.html'><span>Events</span></a></li>
				<li><a href='#'><span>Yearnings of Yore</span></a></li>
				<li class='last'><a href='documents/invitation_brochure.pdf'><span>Invitation Brochure</span></a></li>
			</ul>
		</li>
		<li><a href='last_meet.php'><span>Last Meet</span></a></li>
		<li><a href='#'><span>Gallery</span></a></li>
		<li><a href='#'><span>Students'Alumni Cell</span></a></li>
		<li class='has-sub'><a href='#'><span>Sponsers</span></a>

			<ul>
				<li><a href='page-sponsors/2014/sponsors14.html' target="_blank"><span>Sponsors 2014</span></a></li>
				<li><a href='page-sponsors/2013/sponsors13.html' target="_blank"><span>Sponsors 2013</span></a></li>
				<li><a href='page-sponsors/2012/sponsors12.html' target="_blank"><span>Sponsors 2012</span></a></li>
				<li class='last'><a href='page-sponsors/otkp/otkp.html' target="_blank"><span>Official TimeKeeper</span></a></li>
			</ul>


		</li>
		<li class='last'><a href='contact.php'><span>Contact</span></a></li>
	</ul>			

</div>