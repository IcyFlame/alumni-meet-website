<html>

<head>

	<title>12th Alumni Meet</title>

	<?php include("mainStyle.php");?>
	<?php include("preloader.php");?>

</head>

<body background="bg.jpg">

	<div id="topbar" class="navbar">

		<?php include("menubar.php"); ?>

	</div>

	<br/>
	<br/>

	<div class="container">

		<div class="col-md-2 " style="background:;" id="header">

			<br/>

			<?php include("sponsorsSlider.php");?>

		</div>

		<div class="col-md-8" style="background:">

			<?php include("imageSlider.php");?>

		</div>

		
		<div class="col-md-2" style="background:; text-align:center">

			<?php include("socialIcons.php");?>					

		</div> 

	</div>

</body>

</html>