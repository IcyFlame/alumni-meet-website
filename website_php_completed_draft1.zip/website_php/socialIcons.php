
<br/>

<a href="#"><button class="Login"><span style="color: black">Login</span></button></a> <br/> <br/>
<a href="form.html"><button class="Register"><span style="color: black">Register</span></button></a>

<br/> <br/>

<div>

	<a href="https://www.facebook.com/iitkgp.alumnicell" target="a_blank">
		<img src="social-images/facebook.gif" height="40px" width="40px">
	</a> <br/> <br/>

	<a href="https://www.facebook.com/IIT.Kgp/app_116943498446376" target="a_blank">
		<img src="social-images/twitter.png" height="35px" width="44px">
	</a> <br/> <br/>

	<a href="#" target="a_blank">
		<img src="social-images/linkedin.png" height="48px" width="58px">
	</a> <br/> <br/>

</div>