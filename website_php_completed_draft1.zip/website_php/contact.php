
<html>

<head>

	<title>12th Alumni Meet</title>

	<?php include("mainStyle.php"); ?>

	<style type="text/css">
	#rect{
		position: absolute;
		top: 300px;
		left:90px;
	}
	#p1{position: absolute;

		left:90px;
		right:90px;
		/*top: 100px;*/

	}
	.pic_left{
		position: absolute;
		left: 65px;
	}
	.pic_right{
		position: absolute;
		right: 65px;
	}
	.name_left{
		position: absolute;
		left: 185px;
	}
	.name_right{
		position: absolute;
		right: 185px;
	}


	</style>

</head>

<body background="bg.jpg">

	<div id="topbar" class="navbar">

		<?php include("menubar.php"); ?>

	</div>

	<br/>
	<br/>


	<div id="p1" > 

		<?php include("contactText.php"); ?>

	</div>

</body>

</html>