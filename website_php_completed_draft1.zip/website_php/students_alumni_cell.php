<html>

<head>

	<title>12th Alumni Meet</title>

	<?php include("mainStyle.php");?>

	<style type="text/css">

	.font-type{
		left:120px;
		right:120px;
	}


	</style>

</head>

<body background="bg.jpg">

	<div id="topbar">

		<?php include("menubar.php"); ?>

	</div>
</div>

<br/>
<br/>

<div class="container">

	<?php include("sac_content.php"); ?>

</div>

</body>

</html>