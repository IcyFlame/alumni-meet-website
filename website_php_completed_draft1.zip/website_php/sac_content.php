<div id="p1" >

	<font color="white" size="4";>
		<div class="font-type">
			<center><p allign="justify"><h2  >Students' Alumni Cell</h2><br></p></center>

			&nbsp; &nbsp;&nbsp;&nbsp;Over the course of past few years, Students' Alumni Cell has emerged as a key organ of the

			Office of Alumni Affairs and International Relations in executing its yearlong events and

			activities. Students' Alumni Cell continuously endeavours to strengthen the relations of the

			alumni of this Institute and their alma mater. Formed as and operating under the Dean,

			Alumni Affairs and International Relations, Students' Alumni Cell has been instrumental in

			organizing the Annual Alumni Meet and Regional Student-Alumni Meets, publishing the quarterly alumni newsletter (KGPian), the

			annual literary magazine (Yearnings of Yore) and the Annual Yearbook (Kognosco Gaudeo

			Perficio) and organizing regular guest lectures by distinguished alumni via the initiatives

			“Guest Lecture Conclave” and the “E-Guest Lecture Series”. Students' Alumni Cell also

			operates the Student - Alumni Mentorship Programme, My Imprint (Giving Back - Alumni

			contribution) and organises Alvida (the annual farewell dinner).
		</div>


		<br>
		<div class="details" style="left:35%">
			<center>
				<h1  >The Team</h1><br>
				<h2  >General Secretaries</h2>
				<br/>
				<br/>

				<div class="container">

					<div class="col-md-6">

						<a href=""><h4>gsec1</h4></a>
						<h5>email</h5>
						<h5>phone</h5>	

					</div>

					<div class="col-md-6">

						<a href=""><h4>gsec2</h4></a>
						<h5>email</h5>
						<h5>phone</h5>	

					</div>

				</div>

				<br/>
				<h2>Coordinators</h2>
				<br/>
				<br/>

				<div class="container">

					<div class="col-md-6">

						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>	

					</div>

					<div class="col-md-6">

						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>
						<br/>
						<a href=""><h4>coordinator</h4></a>
						<h5>department</h5>
						<h5>email</h5>
						<h5>phone</h5>	
						<br>

					</div>

				</div>

				<br>
				<h2>Web Team</h2>
				<br>
			</center>
		</div>
	</font>
</div>