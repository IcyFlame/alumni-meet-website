<script src="preloader/jquery.min.js" type="text/javascript"></script>
<script src="preloader/jquery.queryloader2.min.js" type="text/javascript"></script>
<script src="preloader/script.js" type="text/javascript"></script>
