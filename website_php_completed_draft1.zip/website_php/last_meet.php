﻿<html>

<head>

	<title>12th Annual Alumni Meet IITKGP</title>

	<?php include("css_last_meet.php");?>

</head>

<body background="bg.jpg">

	<div id="topbar" class="navbar">

		<?php include("menubar.php"); ?>
		
	</div>

	<br/>
	<br/>

	<?php include("slider_last_meet.php");?>
	
</body>
</html>
