<br/>

<div id="wowslider-container1" style="border-radius: 4px">
	<div class="ws_images">
		<ul>
			<li><img src="data1/images/5270181920x1200.jpg" alt="527018-1920x1200" title="527018-1920x1200" id="wows1_0"/></li>
			<li><img src="data1/images/5439991920x1200.jpg" alt="543999-1920x1200" title="543999-1920x1200" id="wows1_1"/></li>
			<li><img src="data1/images/5570091920x1200.jpg" alt="557009-1920x1200" title="557009-1920x1200" id="wows1_2"/></li>
			<li><img src="data1/images/5576971920x1200.jpg" alt="557697-1920x1200" title="557697-1920x1200" id="wows1_3"/></li>
			<li><img src="data1/images/5652601920x1200.jpg" alt="565260-1920x1200" title="565260-1920x1200" id="wows1_4"/></li>
			<li><img src="data1/images/5697361920x1200.jpg" alt="569736-1920x1200" title="569736-1920x1200" id="wows1_5"/></li>
			<li><img src="data1/images/5840881920x1200.jpg" alt="584088-1920x1200" title="584088-1920x1200" id="wows1_6"/></li>
			<li><img src="data1/images/5265491920x1200.jpg" alt="526549-1920x1200" title="526549-1920x1200" id="wows1_7"/></li>
		</ul>
	</div>
	<div class="ws_bullets">
		<div>
			<a href="#" title="527018-1920x1200"><img src="data1/tooltips/5270181920x1200.jpg" alt="527018-1920x1200"/>1</a>
			<a href="#" title="543999-1920x1200"><img src="data1/tooltips/5439991920x1200.jpg" alt="543999-1920x1200"/>2</a>
			<a href="#" title="557009-1920x1200"><img src="data1/tooltips/5570091920x1200.jpg" alt="557009-1920x1200"/>3</a>
			<a href="#" title="557697-1920x1200"><img src="data1/tooltips/5576971920x1200.jpg" alt="557697-1920x1200"/>4</a>
			<a href="#" title="565260-1920x1200"><img src="data1/tooltips/5652601920x1200.jpg" alt="565260-1920x1200"/>5</a>
			<a href="#" title="569736-1920x1200"><img src="data1/tooltips/5697361920x1200.jpg" alt="569736-1920x1200"/>6</a>
			<a href="#" title="584088-1920x1200"><img src="data1/tooltips/5840881920x1200.jpg" alt="584088-1920x1200"/>7</a>
			<a href="#" title="526549-1920x1200"><img src="data1/tooltips/5265491920x1200.jpg" alt="526549-1920x1200"/>8</a>
		</div>
	</div>
</div>

<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
