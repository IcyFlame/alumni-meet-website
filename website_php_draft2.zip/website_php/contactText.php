<font color="white">
	<center><h2>Postal Addresss</h2>
		<h4>Office of Alumni Affairs & International Relations</h4>
		<h4>Indian Institute of Technology, Kharagpur</h4>
		<h4>Pin-721302, West Bengal, India</h4>
		<h4>Ph: 03222-282236</h4>
		<h4>Email: <a href="mailto:alumni@hijli.iitkgp.ernet.in">alumni@hijli.iitkgp.ernet.in</a></h4>
	</center>	<br><br>

	<img class="pic_left" src="http://alumnimeet.iitkgp.ernet.in/images/sm.jpg" width="100px" height="100px"><br>
	<div class="name_left"><b>Prof. Siddhartha Mukhopadhyay,(EE) Dean, Alumni Affairs & International Relations,  </b></div><br>
	<div class="name_left"><b>Email:</b> <a href="mailto:smukh@ee.iitkgp.ernet.in" target="a_blank">smukh@ee.iitkgp.ernet.in </a> </div>
	<br><br><br><br>
	<img class="pic_right" src="http://alumnimeet.iitkgp.ernet.in/images/Chinna%20Boddipali.jpg"width="100px" height="100px"><br>
	<div class="name_right"><b>Mr. Chinna Babu Boddipalli (AE) Managing Director- Institutional Development,</b>  </div><br>
	<div class="name_right"><b>Email:</b> <a href="mailto:chinna@adm.iitkgp.ernet.in" target="a_blank">chinna@adm.iitkgp.ernet.in</a></div>
	<br><br><br><br>
	<img class="pic_left" src="http://alumnimeet.iitkgp.ernet.in/images/Shampa%20goswami.jpg" width="100px" height="100px "><br>
	<div class="name_left"><b>Ms. Shampa Goswami, Technical Superintendent, Administrative In-charge - AA& IR,   </b> </div><br>
	<div class="name_left"> <b>Email:</b><a href="mailto:shampa@hijli.iitkgp.ernet.in" target="a_blank"> shampa@hijli.iitkgp.ernet.in</a> </div>
	<br><br><br><br>
	<img class="pic_right" src="http://alumnimeet.iitkgp.ernet.in/images/Shreyoshi%20Ghosh.jpg"width="100px" height="100px"><br>
	<div class="name_right"><b>Ms. Shreyoshi Ghosh, Corporate Communication Executive - Institutional Development</b></div><br>
	<div class="name_right"><b>Email:</b><a href="mailto:shreyoshi@adm.iitkgp.ernet.in"> shreyoshi@adm.iitkgp.ernet.in</a>;Ph: +91 3222 277480</div>
	<br><br><br><br>
	<img class="pic_left" src="http://alumnimeet.iitkgp.ernet.in/images/Shruti%20gupta.jpg" width="100px" height="100px"><br>
	<div class="name_left"><b>Ms. Shruti Gupta, Institutional Development Executive - Institutional Development</b> </div><br>
	<div class="name_left"><b>Email:</b><a href=" mailto:shruti@adm.iitkgp.ernet.in" target="a_blank">shruti@adm.iitkgp.ernet.in </a>GSM: 9475371800 </div>
	<br><br><br><br>
	<img class="pic_right" src="http://alumnimeet.iitkgp.ernet.in/images/aditi%20sharma.jpg"width="100px" height="100px"><br>
	<div class="name_right"><b>Ms. Aditi Sharma, General Secretary, Students' Alumni Cell</b></div><br>
	<div class="name_right"><b>Email:</b><a href="mailto:aditiritu.sharma@gmail.com" target="a_blank"> aditiritu.sharma@gmail.com</a>; GSM: +917407659789</div>
	<br><br><br><br>
	<img class="pic_left" src="http://alumnimeet.iitkgp.ernet.in/images/vedang.jpg" width="100px" height="100px"><br>
	<div class="name_left"><b>Mr. Vedang Deshpande, General Secretary, Students' Alumni Cell</b> </div><br>
	<div class="name_left"> <b>Email:</b><a href="mailto:vedang.28@gmail.com" target="a_blank"> vedang.28@gmail.com </a> ; GSM: +918001618061</div>
	<br><br><br>
	<br><br><br><br>
	<div class="pic_left"> <b>Job Assistants:</b> Prasenjit Banerjee, Sadhan Banerjee</div><br>
	<div class="pic_left"><b>Office Assistants:</b> Tapas Panda, Provas Kar</div>

</font>